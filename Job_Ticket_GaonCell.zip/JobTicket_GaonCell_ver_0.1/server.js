// Node.JS 내외부 모듈추출
const   cookieParser = require('cookie-parser');
const   session = require('express-session');
const   bodyParser = require('body-parser');
const   express = require('express');
const   app = express();
const   createError = require('http-errors');
const   path = require('path');

// 잡티켓 개발소스 모듈
const   mainUI = require('./routes/main');
const   user = require('./routes/user');
const   admin = require('./routes/admin');
const   task = require('./routes/task');
const   log = require('./routes/log');
const   myinfo = require('./routes/myinfo');

// 잡티켓 PORT주소 설정
const   PORT = 8000;

// 실행환경 설정부분
app.set('views', path.join(__dirname, 'views'));  // views경로 설정
app.set('view engine', 'ejs');                    // view엔진 지정
app.use(express.static(path.join(__dirname, 'public')));   // public설정
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());
app.use(session({ key: 'sid',
                  secret: 'secret key',  // 세션id 암호화할때 사용
                  resave: false,         // 접속할때마다 id부여금지
                  saveUninitialized: true })); // 세션id사용전에는 발급금지

// URI와 핸들러를 매핑
app.use('/', mainUI);       // URI (/) 접속하면 mainui로 라우팅
app.use('/user', user);   // URI('/user') 접속하면 user로 라우팅
app.use('/admin', admin); // URI('/admin') 접속하면 admin로 라우팅
app.use('/task', task); // URI('/task') 접속하면 task로 라우팅
app.use('/log', log); // URI('/log') 접속하면 log로 라우팅
app.use('/myinfo', myinfo); // URI('/myinfo') 접속하면 myinfo로 라우팅


// 서버를 실행합니다.
app.listen(PORT, function () {
       console.log('서버실행: http://192.168.10.29:' + PORT);
       //console.log('서버실행: http://192.9.80.96:' + PORT);
});