# Job-Ticket
Job Ticket 프로그램 프로젝트

# 개발 프레임워크
backend : Node.js  
frontend : ejs, HTML, CSS  
DB : Mysql

# 버전
ver 0.01 개발완료  
ver 0.1 개발완료  
  
  