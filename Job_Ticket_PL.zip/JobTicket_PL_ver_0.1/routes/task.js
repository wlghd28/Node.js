const   fs          = require('fs');
const   express     = require('express');
const   ejs         = require('ejs');
const   mysql       = require('mysql');
const   bodyParser  = require('body-parser');
const   methodOverride = require('method-override');
const   url = require('url');
//const   session     = require('express-session');
const   router      = express.Router();
//const   requestIp   = require('request-ip');
const   moment      = require('moment');
const   async       = require('async');
//const   xlsx        = require( "xlsx" );
const   exceljs     = require('exceljs');

require('moment-timezone');

router.use(methodOverride('_method'));
router.use(bodyParser.urlencoded({ extended: false }));

/* 
    데이터베이스 연동 소스코드 
*/
const db = mysql.createConnection({
    host:       'localhost',        // DB서버 IP주소
    port:       3306,               // DB서버 Port주소
    user:       'root',             // DB접속 아이디
    password:   'root',             // DB암호
    database:   'Job_ticket'        //사용할 DB명
});

// 로그인 했을 시 보여지는 메인화면
// 현재 진행 중인 업무 리스트가 보여진다.
const RecentTasklist = (req, res) => {
    if (req.session.userid) {  
        
        let sql_str1 = 'SELECT * FROM TASK WHERE manager_id = ? and task_state != 1';
        let sql_str2 = 'SELECT * FROM TASK WHERE manager_id = ? and enddate >= ? and task_state = 1';
        let date = new Date();
        let results1, results2;
        let HtmlPageStream  = '';
    
        HtmlPageStream  += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream  += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        // HtmlPageStream  += fs.readFileSync(__dirname + '/../views/task_searchbar.ejs','utf8');
        HtmlPageStream  += fs.readFileSync(__dirname + '/../views/recent_tasklist.ejs','utf8'); 
        HtmlPageStream  += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        // 현재 날짜에서 2주 전 날짜 계산
        date.setDate(date.getDate() - 14);

        async.waterfall([
            function(callback) {
                db.query(sql_str1, [req.session.userid], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        results1 = results.reverse();
                        callback(null);
                    }
                });
            },
            function(callback) {
                db.query(sql_str2, [req.session.userid, date], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        results2 = results.reverse();
                        callback(null);
                    }
                });               
            },
            function(callback) {
                res.end(ejs.render(HtmlPageStream , {
                    'title'         :'잡티켓',
                    Task            :results1,
                    Task2           :results2
                }));
                callback(null);
            }],
            function(error, result) {
                if (error)
                    console.log(error);
            }
        );
    } else {
        res.redirect('/user/login');
    }
};

// 진행중인 업무리스트의 제목을 클릭할 시 보여지는 업무상세 내용 화면
// 발급자ID와 세션ID가 같을 경우만 업무삭제버튼 활성화
const DoingTaskContent = (req, res) => {
    //console.log("업무상세내용 조회요청");
    if(req.session.userid) {
        let sql_str1 = 'SELECT * FROM TASK WHERE task_num = ?';
        let sql_str2 = 'SELECT * FROM TASK WHERE task_num != ? and task_state != 1 and manager_id = ? order by enddate asc Limit 5';
        let sql_str3 = 'UPDATE TASK SET task_confirm = 0 WHERE task_num = ?';
        let session_id = req.session.userid;
        const  query = url.parse(req.url, true).query;
        var task_results = new Array();

        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/detail_doingtask.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        async.waterfall([
            function(callback) {
                db.query(sql_str1, [query.tasknum], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        task_results.push(results[0]);
                        callback(null);
                    }
                });
            },
            function(callback) {
                db.query(sql_str2, [query.tasknum, query.managerid], (error, results) => {
                    if(error) {
                        //console.log(error);
                        res.end("error");
                    } else {
                        results.forEach((task_data, index) => { 
                            task_results.push(task_data);
                        }); // foreach
                        callback(null);
                    }
                });
            },
            function(callback) {
                if(query.managerid == session_id) {
                    db.query(sql_str3, [query.tasknum], (error) => {
                        if(error) {
                            //console.log(error);
                            res.end("error");
                        } else {
                            //console.log("업무읽음표시");
                            callback(null);
                        }
                    });
                } else
                    callback(null);
            },
            function(callback) {
                //console.log(task_results);
                res.end(ejs.render(HtmlPageStream , {
                    'title'         :'잡티켓',
                    Task            :task_results,
                    session_id      :session_id
                }));
                callback(null);
            }],
            function(error, result) {
                if (error)
                    console.log(error);
            }
        );
    } else {
        res.redirect('/user/login');
    }
};
// 완료된 업무리스트의 제목을 클릭할 시 보여지는 업무상세 내용 화면
// 완료된 업무는 수정 불가
const FinishTaskContent = (req, res) => {
    //console.log("업무상세내용 조회요청");
    if(req.session.userid) {
        let sql_str = 'SELECT * FROM TASK WHERE task_num = ?';
        let session_id = req.session.userid;
        const  query = url.parse(req.url, true).query;
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/detail_finishtask.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        db.query(sql_str, [query.tasknum], (error, results) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                //날짜 색깔변경 테스트
                //console.log((results[0].enddate - results[0].startdate)/(1000*60*60*24));
                res.end(ejs.render(HtmlPageStream , {
                    'title'         :'잡티켓',
                    Task            :results[0],
                    session_id      :session_id
                }));
            }
        });

    } else {
        res.redirect('/user/login');
    }
};

// 업무 등록하는 양식화면
const UploadTaskGet = (req, res) => {
    if (req.session.userid) {  
        let sql_str = 'SELECT * FROM USER WHERE user_id != "admin"';
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/task_upload_form.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        db.query(sql_str, (error, results) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                res.end(ejs.render(HtmlPageStream, {
                    'title'         :'잡티켓',
                    USER            :results
                }));
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 등록
const UploadTaskPost = (req, res) => {
    if (req.session.userid) {  
        // console.log(req.body);
        // console.log('POST 데이터 받음');
        //console.log('업무등록 요청보냄');
        let sql_str1 = 'SELECT user_name, user_level FROM USER WHERE user_id = ?';
        let sql_str2 = 
        'INSERT INTO ' 
        + 'TASK(task_title, task_field, updatedate, startdate, enddate, issuer_id, issuer_name, manager_id, manager_name, task_content, task_result, task_state, task_level)'
        + 'VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
        
        let body = req.body;
        let title = body.title;
        let field = body.field;
        let updatedate = new Date();
        // let startdate = body.startdate;
        let enddate = body.enddate;
        let manager_id = body.managerid;
        let manager_name;
        let content = body.content;
        let task_state = 2;
        let manager_level;

        manager_id = manager_id.split('(');
        //console.log(manager_id);

        // 데이터 테스트
        //console.log(body);
        //console.log(manager_id);

        // 담당자 이름과 직급을 DB에서 담당자ID를 통해 가져온다.
        db.query(sql_str1, [manager_id[0]], (error, results) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                if(results.length <= 0) {
                    let HtmlPageStream = '';
    
                    HtmlPageStream += fs.readFileSync(__dirname + '/../views/alert.ejs','utf8');     
                    res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

                    res.status(562).end(ejs.render(HtmlPageStream, {
                        'title' : 'error',
                        'url'   : '/task/upload',
                        'error' : '담당자 ID정보가 없습니다!!'
                    }));  
                } else {

                    // DB에서 가져온 담당자 이름을 변수에 저장.
                    manager_name = results[0].user_name;
                    manager_level = results[0].user_level;
                    // TASK 테이블에 데이터 삽입.
                    db.query(sql_str2, [title, field, updatedate, updatedate, enddate, req.session.userid, req.session.who, manager_id[0], manager_name, content, null, task_state, manager_level], (error) => {
                        if (error) {     
                            console.log(error);
                            res.end("error");
                        } else {
                            //console.log("업무등록 성공");
                            res.redirect('/task');   
                        }
                    });
                }
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 전체업무 목록 출력
// 업무의 담당자 id와 세션 id가 다를 경우 상세내용 링크 비활성화
const TaskAlllist = (req, res) => {
    if (req.session.userid) {  

        let sql_str1 = 'SELECT * FROM TASK WHERE task_level <= ? and task_state != 1';
        let sql_str2 = 'SELECT * FROM TASK WHERE task_level <= ? and task_state = 1 and enddate >= ?';
        let session_id = req.session.userid;
        let session_level = req.session.level;
        let date = new Date();
        let results1, results2;
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');   
        // HtmlPageStream += fs.readFileSync(__dirname + '/../views/task_searchbar.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/all_tasklist.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        // 현재 날짜에서 2주 전 날짜 계산
        date.setDate(date.getDate() - 14);

        async.waterfall([
            function(callback) {
                db.query(sql_str1, [session_level], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        results1 = results.reverse();
                        callback(null);
                    }
                });
            },
            function(callback) {
                db.query(sql_str2, [session_level, date], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        results2 = results.reverse();
                        callback(null);
                    }
                });               
            },
            function(callback) {
                res.end(ejs.render(HtmlPageStream , {
                    'title'         :'잡티켓',
                    session_id      :session_id,
                    Task            :results1,
                    Task2           :results2
                }));
                callback(null);
            }
        ],  function(error, result) {
            if (error)
                console.log(error);
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 수정하는 양식화면
const UpdateTaskGet = (req, res) => {
    if (req.session.userid) {  

        let sql_str = 'SELECT * FROM TASK WHERE task_num = ?';
        const  query = url.parse(req.url, true).query;
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/task_update_form.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        db.query(sql_str, [query.tasknum], (error, results) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                res.end(ejs.render(HtmlPageStream, {
                    'title'         :'잡티켓',
                    Task            :results[0]
                }));
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 수정
const UpdateTaskPut = (req, res) => {
    if (req.session.userid) {  
        let sql_str = 'UPDATE TASK SET task_title = ?, task_field = ?, startdate = ?, enddate = ?, task_content = ? WHERE task_num = ?';
        let body = req.body;

        //console.log(body);

        db.query(sql_str, [body.title, body.field, body.startdate, body.enddate, body.content, body.tasknum], (error) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                //console.log("업무수정 성공");
                res.redirect('/task');
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 삭제
const DeleteTask = (req, res) => {
    if (req.session.userid) {  
        let sql_str = 'DELETE FROM TASK WHERE task_num = ?';
        let body = req.body;

        db.query(sql_str, [body.tasknum], (error) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                //console.log("업무삭제 성공");
                res.redirect('/task');
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 검색
const SearchTask = (req, res) => {
    if (req.session.userid) {  
        let sql_str;
        const  query = url.parse(req.url, true).query;
        let session_level = req.session.level;
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');   
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/task_searchbar.ejs','utf8');    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/search_tasklist.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        //console.log(typeof(query.condition));
        switch(query.condition) {
            case "발급자":
                sql_str = "SELECT * FROM TASK WHERE task_level <= ? and issuer_name LIKE '%" + query.search + "%'";
                db.query(sql_str, [session_level], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {                
                        res.end(ejs.render(HtmlPageStream, {
                            'title'         :'잡티켓',
                            Task            :results,
                            Task2           :results
                        }));
                    }
                });
            break;

            case "담당자":
                sql_str = "SELECT * FROM TASK WHERE task_level <= ? and manager_name LIKE '%" + query.search + "%'";
                db.query(sql_str, [session_level], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {                
                        res.end(ejs.render(HtmlPageStream, {
                            'title'         :'잡티켓',
                            Task            :results,
                            Task2           :results
                        }));
                    }
                });
            break;

            case "업무제목":
                sql_str = "SELECT * FROM TASK WHERE task_level <= ? and task_title LIKE '%" + query.search + "%'";
                db.query(sql_str, [session_level], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {                
                        res.end(ejs.render(HtmlPageStream, {
                            'title'         :'잡티켓',
                            Task            :results,
                            Task2           :results
                        }));
                    }
                });
            break;

            case "업무내용":
                sql_str = "SELECT * FROM TASK WHERE task_level <= ? and task_content LIKE '%" + query.search + "%'";
                db.query(sql_str, [session_level], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {                
                        res.end(ejs.render(HtmlPageStream, {
                            'title'         :'잡티켓',
                            Task            :results,
                            Task2           :results
                        }));
                    }
                });
            break;
            
            default:
                res.end(ejs.render(HtmlPageStream, {
                    'title'         :'잡티켓',
                    Task            :null,
                    Task2           :null
                }));
        }

        
    } else {
        res.redirect('/user/login');
    }
};

// 날짜로 업무 검색
const SearchDateTask = (req, res) => {
    if (req.session.userid) {  
        let sql_str = 'SELECT * FROM TASK WHERE task_level <= ? and startdate <= ? and enddate >= ?';
        const  query = url.parse(req.url, true).query;
        let session_level = req.session.level;
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');   
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/task_searchbar.ejs','utf8');    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/search_tasklist.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        //console.log(typeof(query.condition));
        if(query.taskdate != '') {
            db.query(sql_str, [session_level, query.taskdate, query.taskdate], (error, results) => {
                if(error) {
                    console.log(error);
                    res.end("error");
                } else {
                    res.end(ejs.render(HtmlPageStream, {
                        'title'         :'잡티켓',
                        Task            :results,
                        Task2           :results
                    }));
                }
            });
        } else {
            res.end(ejs.render(HtmlPageStream, {
                'title'         :'잡티켓',
                Task            :null,
                Task2           :null
            }));
        }
        
    } else {
        res.redirect('/user/login');
    }
};

// 업무 완료하는 양식 화면
// 업무 처리결과를 입력하는 화면
const FinishTaskGet = (req, res) => {
    if (req.session.userid) {  
        let sql_str = 'SELECT * FROM TASK WHERE task_num = ?';
        const  query = url.parse(req.url, true).query;
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/task_finish_form.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        db.query(sql_str, [query.tasknum], (error, results) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                res.end(ejs.render(HtmlPageStream, {
                    'title'         :'잡티켓',
                    Task            :results[0]
                }));
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 시작
const StartTaskPut = (req, res) => {
    if (req.session.userid) {  
        let sql_str = 'UPDATE TASK SET task_state = 0, startdate = ? WHERE task_num = ?';
        let date = new Date();
        let body = req.body;
        //console.log(body);

        db.query(sql_str, [date, body.tasknum], (error) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                //console.log("업무시작 성공");
                res.redirect('/task');
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 보류
const HoldTaskPut = (req, res) => {
    if (req.session.userid) {  
        let sql_str = 'UPDATE TASK SET task_state = 3 WHERE task_num = ?';
        let body = req.body;
        //console.log(body);

        db.query(sql_str, [body.tasknum], (error) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                //console.log("업무보류 성공");
                res.redirect('/task');
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 완료
const FinishTaskPut = (req, res) => {
    if (req.session.userid) {  
        let sql_str = 'UPDATE TASK SET task_state = 1, task_result = ?, enddate = ? WHERE task_num = ?';
        let date = new Date();
        let body = req.body;
        //console.log(body);

        db.query(sql_str, [body.result, date, body.tasknum], (error) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                //console.log("업무완료 성공");
                res.redirect('/task');
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 보고서 작성 할 때 업무 기간 설정하는 페이지
const ReportPage = (req, res) => {
    if (req.session.userid) {  
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/report_page.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        res.end(ejs.render(HtmlPageStream, {
            'title'         :'잡티켓'
        }));

    } else {
        res.redirect('/user/login');
    }
};

// 보고서 작성
// 엑셀 파일을 생성하여 클라이언트에 전송
const ReportDownload = (req, res) => {
    if (req.session.userid) {  
        let sql_str1 = 'SELECT task_field, task_state, task_title, task_content, issuer_name, manager_name, startdate, enddate FROM TASK WHERE manager_id = ? and enddate >= ? and startdate < ?';
        let sql_str2 = 'SELECT task_field, task_state, task_title, task_content, issuer_name, manager_name, startdate, enddate FROM TASK WHERE manager_id = ? and enddate > ? and startdate <= ?';
        let sql_str3 = 'SELECT task_field, task_state, task_title, task_content, issuer_name, manager_name, startdate, enddate FROM TASK WHERE manager_id = ? and enddate <= ? and startdate >= ?';
        const  query = url.parse(req.url, true).query;
        let manager_id = req.session.userid;
        let state = ['진행중', '완료', '발급', '보류'];
        const workbook = new exceljs.Workbook();;
        let data_sheet = workbook.addWorksheet("Report");
        let task = new Array()
        let date = new Date();

        // console.log(query);
        // console.log(data_sheet);
        // 입력 받은 날짜조건에 맞는 데이터를 DB에서 추출
        async.waterfall([
            function(callback) {
                db.query(sql_str1, [manager_id, query.startdate, query.startdate], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        results.forEach((task_data, index) =>{
                            if(task_data.task_state == 0 && task_data.enddate < date) {
                                task.push([task_data.task_field, "마감" , task_data.task_title, task_data.task_content, 
                                    task_data.issuer_name, task_data.manager_name, moment(task_data.startdate).format("YYYY-MM-DD"), moment(task_data.enddate).format("YYYY-MM-DD")]);
                            } else{
                                task.push([task_data.task_field, state[task_data.task_state], task_data.task_title, task_data.task_content, 
                                    task_data.issuer_name, task_data.manager_name, moment(task_data.startdate).format("YYYY-MM-DD"), moment(task_data.enddate).format("YYYY-MM-DD")]);
                            }
                        });
                        callback(null);
                    }
                });
            },
            function(callback) {
                db.query(sql_str2, [manager_id, query.enddate, query.enddate], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        results.forEach((task_data, index) =>{
                            if(task_data.task_state == 0 && task_data.enddate < date) {
                                task.push([task_data.task_field, "마감" , task_data.task_title, task_data.task_content, 
                                    task_data.issuer_name, task_data.manager_name, moment(task_data.startdate).format("YYYY-MM-DD"), moment(task_data.enddate).format("YYYY-MM-DD")]);
                            } else{
                                task.push([task_data.task_field, state[task_data.task_state], task_data.task_title, task_data.task_content, 
                                    task_data.issuer_name, task_data.manager_name, moment(task_data.startdate).format("YYYY-MM-DD"), moment(task_data.enddate).format("YYYY-MM-DD")]);
                            }
                        });
                        callback(null);
                    }
                });
            },
            function(callback) {
                db.query(sql_str3, [manager_id, query.enddate, query.startdate], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        results.forEach((task_data, index) =>{
                            if(task_data.task_state == 0 && task_data.enddate < date) {
                                task.push([task_data.task_field, "마감" , task_data.task_title, task_data.task_content, 
                                    task_data.issuer_name, task_data.manager_name, moment(task_data.startdate).format("YYYY-MM-DD"), moment(task_data.enddate).format("YYYY-MM-DD")]);
                            } else{
                                task.push([task_data.task_field, state[task_data.task_state], task_data.task_title, task_data.task_content, 
                                    task_data.issuer_name, task_data.manager_name, moment(task_data.startdate).format("YYYY-MM-DD"), moment(task_data.enddate).format("YYYY-MM-DD")]);
                            }
                        });
                        callback(null);
                    }
                });
            },
            function(callback) {       
                // 엑셀 열 정보 지정
                data_sheet.columns = [
                    {header:'분야', width: 8},
                    {header:'상태', width: 8},
                    {header:'제목', width: 20},
                    {header:'내용', width: 40},
                    {header:'발급자', width: 8},
                    {header:'담당자', width: 8},
                    {header:'시작날짜', width: 12, style: {Date}},
                    {header:'마감날짜', width: 12, style: {Date}}
                ];

                // 데이터 시트에 task 배열 데이터 매핑
                data_sheet.addRows(task);

                // 클라이언트에 엑셀파일 전송
                res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                res.setHeader("Content-Disposition", "attachment; filename="+"report.xlsx");
                workbook.xlsx.write(res).then((error) => {
                    if(error) {
                        res.end("error");
                    } else {
                        res.redirect('/task');
                    }
                });

                // // 엑셀 파일 서버에 생성
                // workbook.xlsx.writeFile('./Report.xlsx').then((success)=>{
                //     //console.log('완료');
                // 
                // }).catch((error)=>{
                //     console.log(error);
                // });
            },
        ],  function(error, result) {
            if (error)
                console.log(error);
        });

    } else {
        res.redirect('/user/login');
    }
};

// router를 메서드에 따라서 호출
router.get('/',    RecentTasklist);

router.get('/all',    TaskAlllist);

router.get('/doingcontent',   DoingTaskContent);
router.get('/finishcontent',   FinishTaskContent);

router.get('/upload',   UploadTaskGet);
router.post('/upload',   UploadTaskPost);

router.get('/update',   UpdateTaskGet);
router.put('/update',   UpdateTaskPut);

router.delete('/delete',   DeleteTask);

router.get('/search',   SearchTask);
router.get('/date', SearchDateTask);

router.put('/start', StartTaskPut);

router.put('/hold', HoldTaskPut);

router.get('/finish',   FinishTaskGet);
router.put('/finish',   FinishTaskPut);

router.get('/report_download',   ReportDownload);
router.get('/report_page',   ReportPage);

// 외부모듈로 추출
module.exports = router
