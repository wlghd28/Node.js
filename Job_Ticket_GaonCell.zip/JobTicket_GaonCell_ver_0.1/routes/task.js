const   fs          = require('fs');
const   express     = require('express');
const   ejs         = require('ejs');
const   mysql       = require('mysql');
const   bodyParser  = require('body-parser');
const   methodOverride = require('method-override');
const   url = require('url');
//const   session     = require('express-session');
const   router      = express.Router();
//const   requestIp   = require('request-ip');
//const   moment      = require('moment');
const   async       = require('async');

require('moment-timezone');

router.use(methodOverride('_method'));
router.use(bodyParser.urlencoded({ extended: false }));

/* 
    데이터베이스 연동 소스코드 
*/
const db = mysql.createConnection({
    host:       'localhost',        // DB서버 IP주소
    port:       3306,               // DB서버 Port주소
    user:       'root',             // DB접속 아이디
    password:   'root',             // DB암호
    database:   'Job_ticket'        //사용할 DB명
});

// 로그인 했을 시 보여지는 메인화면
// 현재 진행 중인 업무 리스트가 보여진다.
const RecentTasklist = (req, res) => {
    if (req.session.userid) {  
        
        let sql_str1 = 'SELECT * FROM TASK WHERE manager_id = ? and task_state != 1';
        let sql_str2 = 'SELECT * FROM TASK WHERE manager_id = ? and enddate >= ? and task_state = 1';
        let date = new Date();
        let results1, results2;
        let HtmlPageStream  = '';
    
        HtmlPageStream  += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream  += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream  += fs.readFileSync(__dirname + '/../views/task_searchbar.ejs','utf8');
        HtmlPageStream  += fs.readFileSync(__dirname + '/../views/recent_tasklist.ejs','utf8'); 
        HtmlPageStream  += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        // 현재 날짜에서 2주 전 날짜 계산
        date.setDate(date.getDate() - 14);

        async.waterfall([
            function(callback) {
                db.query(sql_str1, [req.session.userid], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        results1 = results.reverse();
                        callback(null);
                    }
                });
            },
            function(callback) {
                db.query(sql_str2, [req.session.userid, date], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        results2 = results.reverse();
                        callback(null);
                    }
                });               
            },
            function(callback) {
                res.end(ejs.render(HtmlPageStream , {
                    'title'         :'잡티켓',
                    Task            :results1,
                    Task2           :results2
                }));
                callback(null);
            }],
            function(error, result) {
                if (error)
                    console.log(error);
            }
        );
    } else {
        res.redirect('/user/login');
    }
};

// 업무리스트의 제목을 클릭할 시 보여지는 업무상세 내용 화면
// 발급자ID와 세션ID가 같을 경우만 업무삭제버튼 활성화
const TaskContent = (req, res) => {
    //console.log("업무상세내용 조회요청");
    if(req.session.userid) {
        let sql_str = 'SELECT * FROM TASK WHERE task_num = ?';
        let session_id = req.session.userid;
        const  query = url.parse(req.url, true).query;
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/detail_task.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        db.query(sql_str, [query.tasknum], (error, results) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                //날짜 색깔변경 테스트
                //console.log((results[0].enddate - results[0].startdate)/(1000*60*60*24));
                res.end(ejs.render(HtmlPageStream , {
                    'title'         :'잡티켓',
                    Task            :results[0],
                    session_id      :session_id
                }));
            }
        });

    } else {
        res.redirect('/user/login');
    }
};

// 업무 등록하는 양식화면
const UploadTaskGet = (req, res) => {
    if (req.session.userid) {  
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/task_upload_form.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        res.end(ejs.render(HtmlPageStream, {
            'title'         :'잡티켓'
        }));
    } else {
        res.redirect('/user/login');
    }
};

// 업무 등록
const UploadTaskPost = (req, res) => {
    if (req.session.userid) {  
        // console.log(req.body);
        // console.log('POST 데이터 받음');
        //console.log('업무등록 요청보냄');
        let sql_str1 = 'SELECT user_name, user_level FROM USER WHERE user_id = ?';
        let sql_str2 = 
        'INSERT INTO ' 
        + 'TASK(task_title, task_field, updatedate, startdate, enddate, issuer_id, issuer_name, manager_id, manager_name, task_content, task_result, task_state, task_level)'
        + 'VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
        
        let body = req.body;
        let title = body.title;
        let field = body.field;
        let updatedate = new Date();
        let startdate = body.startdate;
        let enddate = body.enddate;
        let manager_id = body.managerid;
        let manager_name;
        let content = body.content;
        let task_state = 2;
        let manager_level;
    
        // 데이터 테스트
        //console.log(body);
        //console.log(manager_id);

        // 담당자 이름과 직급을 DB에서 담당자ID를 통해 가져온다.
        db.query(sql_str1, [manager_id], (error, results) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                if(results.length <= 0) {
                    let HtmlPageStream = '';
    
                    HtmlPageStream += fs.readFileSync(__dirname + '/../views/alert.ejs','utf8');     
                    res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

                    res.status(562).end(ejs.render(HtmlPageStream, {
                        'title' : 'error',
                        'url'   : '/task/upload',
                        'error' : '담당자 ID정보가 없습니다!!'
                    }));  
                } else {

                    // DB에서 가져온 담당자 이름을 변수에 저장.
                    manager_name = results[0].user_name;
                    manager_level = results[0].user_level;
                    // TASK 테이블에 데이터 삽입.
                    db.query(sql_str2, [title, field, updatedate, startdate, enddate, req.session.userid, req.session.who, manager_id, manager_name, content, null, task_state, manager_level], (error) => {
                        if (error) {     
                            console.log(error);
                            res.end("error");
                        } else {
                            //console.log("업무등록 성공");
                            res.redirect('/task');   
                        }
                    });
                }
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 전체업무 목록 출력
// 업무의 담당자 id와 세션 id가 다를 경우 상세내용 링크 비활성화
const TaskAlllist = (req, res) => {
    if (req.session.userid) {  

        let sql_str1 = 'SELECT * FROM TASK WHERE task_level <= ? and task_state != 1';
        let sql_str2 = 'SELECT * FROM TASK WHERE task_level <= ? and task_state = 1 and enddate >= ?';
        let session_id = req.session.userid;
        let session_level = req.session.level;
        let date = new Date();
        let results1, results2;
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');   
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/task_searchbar.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/all_tasklist.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        // 현재 날짜에서 2주 전 날짜 계산
        date.setDate(date.getDate() - 14);

        async.waterfall([
            function(callback) {
                db.query(sql_str1, [session_level], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        results1 = results.reverse();
                        callback(null);
                    }
                });
            },
            function(callback) {
                db.query(sql_str2, [session_level, date], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        results2 = results.reverse();
                        callback(null);
                    }
                });               
            },
            function(callback) {
                res.end(ejs.render(HtmlPageStream , {
                    'title'         :'잡티켓',
                    session_id      :session_id,
                    Task            :results1,
                    Task2           :results2
                }));
                callback(null);
            }
        ],  function(error, result) {
            if (error)
                console.log(error);
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 수정하는 양식화면
const UpdateTaskGet = (req, res) => {
    if (req.session.userid) {  

        let sql_str = 'SELECT * FROM TASK WHERE task_num = ?';
        const  query = url.parse(req.url, true).query;
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/task_update_form.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        db.query(sql_str, [query.tasknum], (error, results) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                res.end(ejs.render(HtmlPageStream, {
                    'title'         :'잡티켓',
                    Task            :results[0]
                }));
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 수정
const UpdateTaskPut = (req, res) => {
    if (req.session.userid) {  
        let sql_str = 'UPDATE TASK SET task_title = ?, task_field = ?, startdate = ?, enddate = ?, task_content = ? WHERE task_num = ?';
        let body = req.body;

        //console.log(body);

        db.query(sql_str, [body.title, body.field, body.startdate, body.enddate, body.content, body.tasknum], (error) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                //console.log("업무수정 성공");
                res.redirect('/task');
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 삭제
const DeleteTask = (req, res) => {
    if (req.session.userid) {  
        let sql_str = 'DELETE FROM TASK WHERE task_num = ?';
        let body = req.body;

        db.query(sql_str, [body.tasknum], (error) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                //console.log("업무삭제 성공");
                res.redirect('/task');
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 검색
const SearchTask = (req, res) => {
    if (req.session.userid) {  
        let sql_str;
        const  query = url.parse(req.url, true).query;
        let session_level = req.session.level;
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');   
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/task_searchbar.ejs','utf8');    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/search_tasklist.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        //console.log(typeof(query.condition));
        switch(query.condition) {
            case "발급자":
                sql_str = "SELECT * FROM TASK WHERE task_level <= ? and issuer_name LIKE '%" + query.search + "%'";
                db.query(sql_str, [session_level], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {                
                        res.end(ejs.render(HtmlPageStream, {
                            'title'         :'잡티켓',
                            Task            :results,
                            Task2           :results
                        }));
                    }
                });
            break;

            case "담당자":
                sql_str = "SELECT * FROM TASK WHERE task_level <= ? and manager_name LIKE '%" + query.search + "%'";
                db.query(sql_str, [session_level], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {                
                        res.end(ejs.render(HtmlPageStream, {
                            'title'         :'잡티켓',
                            Task            :results,
                            Task2           :results
                        }));
                    }
                });
            break;

            case "업무제목":
                sql_str = "SELECT * FROM TASK WHERE task_level <= ? and task_title LIKE '%" + query.search + "%'";
                db.query(sql_str, [session_level], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {                
                        res.end(ejs.render(HtmlPageStream, {
                            'title'         :'잡티켓',
                            Task            :results,
                            Task2           :results
                        }));
                    }
                });
            break;

            case "업무내용":
                sql_str = "SELECT * FROM TASK WHERE task_level <= ? and task_content LIKE '%" + query.search + "%'";
                db.query(sql_str, [session_level], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {                
                        res.end(ejs.render(HtmlPageStream, {
                            'title'         :'잡티켓',
                            Task            :results,
                            Task2           :results
                        }));
                    }
                });
            break;
            
            default:
        }

        
    } else {
        res.redirect('/user/login');
    }
};

// 업무 완료하는 양식 화면
// 업무 처리결과를 입력하는 화면
const FinishTaskGet = (req, res) => {
    if (req.session.userid) {  

        let sql_str = 'SELECT * FROM TASK WHERE task_num = ?';
        const  query = url.parse(req.url, true).query;
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/task_finish_form.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        db.query(sql_str, [query.tasknum], (error, results) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                res.end(ejs.render(HtmlPageStream, {
                    'title'         :'잡티켓',
                    Task            :results[0]
                }));
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 시작
const StartTaskPut = (req, res) => {
    if (req.session.userid) {  
        let sql_str = 'UPDATE TASK SET task_state = 0, startdate = ? WHERE task_num = ?';
        let date = new Date();
        let body = req.body;
        //console.log(body);

        db.query(sql_str, [date, body.tasknum], (error) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                //console.log("업무시작 성공");
                res.redirect('/task');
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 업무 완료
const FinishTaskPut = (req, res) => {
    if (req.session.userid) {  
        let sql_str = 'UPDATE TASK SET task_state = 1, task_result = ?, enddate = ? WHERE task_num = ?';
        let date = new Date();
        let body = req.body;
        //console.log(body);

        db.query(sql_str, [body.result, date, body.tasknum], (error) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                //console.log("업무완료 성공");
                res.redirect('/task');
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 보고서 작성
const Report = (req, res) => {

};

// router를 메서드에 따라서 호출
router.get('/',    RecentTasklist);

router.get('/all',    TaskAlllist);

router.get('/content',   TaskContent);

router.get('/upload',   UploadTaskGet);
router.post('/upload',   UploadTaskPost);

router.get('/update',   UpdateTaskGet);
router.put('/update',   UpdateTaskPut);

router.delete('/delete',   DeleteTask);

router.get('/search',   SearchTask);

router.put('/start', StartTaskPut);

router.get('/finish',   FinishTaskGet);
router.put('/finish',   FinishTaskPut);

router.get('/report',   Report);

// 외부모듈로 추출
module.exports = router
