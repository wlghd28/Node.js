const   fs          = require('fs');
const   express     = require('express');
const   ejs         = require('ejs');
const   mysql       = require('mysql');
const   bodyParser  = require('body-parser');
const   methodOverride = require('method-override');
//const   session     = require('express-session');
const   router      = express.Router();
//const   requestIp   = require('request-ip');
//const   moment      = require('moment');
require('moment-timezone');

router.use(methodOverride('_method'));
router.use(bodyParser.urlencoded({ extended: false }));

/* 
    데이터베이스 연동 소스코드 
*/
const db = mysql.createConnection({
    host:       'localhost',        // DB서버 IP주소
    port:       3306,               // DB서버 Port주소
    user:       'root',             // DB접속 아이디
    password:   'root',             // DB암호
    database:   'Job_ticket'   //사용할 DB명
});

// 내 정보 조회
const InquireMyinfo = (req, res) => {
    if (req.session.userid) {  

        let sql_str = 'SELECT * FROM USER WHERE user_id = ?';
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/myinfo.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        db.query(sql_str, [req.session.userid], (error, results) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                res.end(ejs.render(HtmlPageStream, {
                    'title'         :'잡티켓',
                    Myinfo            :results[0]
                }));
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 내 정보 수정 양식 화면
const UpdateMyinfoGet = (req, res) => {

};

// 내 정보 수정
const UpdateMyinfoPut = (req, res) => {

};

router.get('/inquire',   InquireMyinfo);
router.get('/update',   UpdateMyinfoGet);
router.put('/update',   UpdateMyinfoPut);

module.exports = router