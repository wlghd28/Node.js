const   fs          = require('fs');
const   express     = require('express');
const   ejs         = require('ejs');
const   mysql       = require('mysql');
const   bodyParser  = require('body-parser');
const   methodOverride = require('method-override');
const   url = require('url');
//const   session     = require('express-session');
const   router      = express.Router();
//const   requestIp   = require('request-ip');
const   moment      = require('moment');
// const   os          = require('os');
require('moment-timezone');

router.use(methodOverride('_method'));
router.use(bodyParser.urlencoded({ extended: false }));

/* 
    데이터베이스 연동 소스코드 
*/
const db = mysql.createConnection({
    host:       'localhost',        // DB서버 IP주소
    port:       3306,               // DB서버 Port주소
    user:       'root',             // DB접속 아이디
    password:   'root',             // DB암호
    database:   'Job_ticket'   //사용할 DB명
});

// 접속로그 최근목록을 보여줍니다.
const InquireLog = (req, res) => {
    if (req.session.userid) {  

        let sql_str = 'SELECT * FROM LOG WHERE log_date >= ?';
        let date = new Date();
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');     
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/log_searchbar.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/recent_loglist.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        // 현재 날짜에서 2주 전 날짜 계산
        date.setDate(date.getDate() - 14);

        db.query(sql_str, [date], (error, results) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                results.reverse();
                res.end(ejs.render(HtmlPageStream, {
                    'title'         :'잡티켓',
                    Log            :results
                }));
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 접속로그 검색목록을 보여줍니다.(아이디/이름 조건)
const SearchLog = (req, res) => {
    if (req.session.userid) {  
        const  query = url.parse(req.url, true).query;
        let sql_str;
        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');   
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/log_searchbar.ejs','utf8');    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/search_loglist.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        switch(query.condition) {
            case "아이디" :
                sql_str = "SELECT * FROM LOG WHERE log_id = ?";
                db.query(sql_str, [query.search], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else { 
                        results.reverse();               
                        res.end(ejs.render(HtmlPageStream, {
                            'title'         :'잡티켓',
                            Log             :results
                        }));
                    }
                });
            break;
            case "이름":
                sql_str = "SELECT * FROM LOG WHERE log_name = ?";
                db.query(sql_str, [query.search], (error, results) => {
                    if(error) {
                        console.log(error);
                        res.end("error");
                    } else {    
                        results.reverse();            
                        res.end(ejs.render(HtmlPageStream, {
                            'title'         :'잡티켓',
                            Log             :results
                        }));
                    }
                });
            break;
            default:
        }

    } else {
        res.redirect('/user/login');
    }
};

// 접속로그 검색목록을 보여줍니다.(날짜 조건)
const DateLog = (req, res) => {
    if (req.session.userid) {  
        const  query = url.parse(req.url, true).query;
        let date_str = query.logdate;
        let date_strArr = date_str.split('-');
        let date = new Date(date_strArr[0], date_strArr[1] - 1, date_strArr[2]);

        let sql_str = "SELECT * FROM LOG WHERE log_date = ?";

        let HtmlPageStream = '';
    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/header.ejs','utf8');  
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/navbar.ejs','utf8');   
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/log_searchbar.ejs','utf8');    
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/search_loglist.ejs','utf8'); 
        HtmlPageStream += fs.readFileSync(__dirname + '/../views/footer.ejs','utf8'); 
        res.writeHead(200, {'Content-Type':'text/html; charset=utf8'});

        //console.log(query.logdate);

        db.query(sql_str, [date], (error, results) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {      
                results.reverse();       
                res.end(ejs.render(HtmlPageStream, {
                    'title'         :'잡티켓',
                    Log             :results
                }));
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

// 접속로그를 추가합니다.
const InsertLog = (req ,res) => {
    if (req.session.userid) {  
        let userid = req.session.userid;
        let username = req.session.who;
        let ipaddress = req.ip.split(":");
        //let ipaddress = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
        moment.tz.setDefault("Asia/Seoul");
        let date = moment().format('YYYY-MM-DD');
        let time = moment().format('YYYY-MM-DD HH:mm:ss');

        if(ipaddress[3] == null)
            ipaddress[3] = '::1';
        // console.log(req.ip);
        // console.log(ipaddress);
        //console.log(date);

        let sql_str = 'INSERT INTO LOG(log_id, log_name, log_ipaddress, log_date, log_time) VALUES(?, ?, ?, ?, ?)';

        db.query(sql_str, [userid, username, ipaddress[3], date, time], (error) => {
            if(error) {
                console.log(error);
                res.end("error");
            } else {
                // 접속로그를 추가한 후에 메인화면으로 이동
                res.redirect('/task');
            }
        });
    } else {
        res.redirect('/user/login');
    }
};

router.get('/', InquireLog);
router.get('/search', SearchLog);
router.get('/date', DateLog);
router.get('/insert', InsertLog);

module.exports = router
