// Node.JS 내외부 모듈추출
const   cookieParser = require('cookie-parser');
const   session = require('express-session');
const   bodyParser = require('body-parser');
const   express = require('express');
const   os = require('os');
const   createError = require('http-errors');
const   path = require('path');
const   app = express();
const   http = require('http').Server(app); //1
const   io = require('socket.io')(http);  //1
const   mysql       = require('mysql');


// 접속된 클라이언트의 아이디, 이름이 저장될 전역 배열
var __Clients = new Array();



// 잡티켓 개발소스 모듈
const   mainUI = require('./routes/main');
const   user = require('./routes/user');
const   admin = require('./routes/admin');
const   task = require('./routes/task');
const   log = require('./routes/log');
const   myinfo = require('./routes/myinfo');
const   chat = require('./routes/user_chat');


/* 
    데이터베이스 연동 소스코드 
*/
const db = mysql.createConnection({
    host:       'localhost',        // DB서버 IP주소
    port:       3306,               // DB서버 Port주소
    user:       'root',             // DB접속 아이디
    password:   'root',             // DB암호
    database:   'Job_ticket'        //사용할 DB명
});

// 잡티켓 PORT주소 설정
const   PORT = 8000;
/*
    포트번호를 외부 모듈로 뺍니다.
*/
module.exports.PORT = PORT;

// 실행환경 설정부분
app.set('views', path.join(__dirname, 'views'));  // views경로 설정
app.set('view engine', 'ejs');                    // view엔진 지정
app.use(express.static(path.join(__dirname, 'public')));   // public설정
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());
app.use(session({ key: 'sid',
                  secret: 'secret key',  // 세션id 암호화할때 사용
                  resave: false,         // 접속할때마다 id부여금지
                  saveUninitialized: true })); // 세션id사용전에는 발급금지

// URI와 핸들러를 매핑
app.use('/', mainUI);       // URI (/) 접속하면 mainui로 라우팅
app.use('/user', user);   // URI('/user') 접속하면 user로 라우팅
app.use('/admin', admin); // URI('/admin') 접속하면 admin로 라우팅
app.use('/task', task); // URI('/task') 접속하면 task로 라우팅
app.use('/log', log); // URI('/log') 접속하면 log로 라우팅
app.use('/myinfo', myinfo); // URI('/myinfo') 접속하면 myinfo로 라우팅
app.use('/user_chat', chat); // URI('/myinfo') 접속하면 myinfo로 라우팅


// 서버를 실행합니다.
http.listen(PORT, function () {
    let ip_address = getServerIp();
    // ip주소를 외부 모듈로 뺍니다.
    module.exports.ip = ip_address;
    console.log('서버실행 : ' + 'http://' + ip_address + ':' + PORT);
});



/*
    채팅 socket.io 서버 실행
*/
io.on('connection', function(socket) {
    //console.log('소켓연결확인!');
    // 새로운 유저가 접속했을 경우 기존에 존재하던 유저들에게 알려줌 (순서 1-2)
    socket.on('newUser', function(user) { 
        //console.log(name + '님이 접속하셨습니다.'); 

        // 소켓의 name 속성에 객체 저장
        socket.name = user;

        // 소켓 통신에 접속된 클라이언트 개수
        //console.log(socket.server.engine.clientsCount);
        // 모든 유저에게 전송
        var object = {
            string : socket.name.name + '(' + socket.name.id + ')' + '님이 접속하셨습니다.',
            id : user.id,
            name : socket.name.name
        };

        __Clients.push(object);
        io.sockets.emit('connectNotice', object, __Clients);
    });
    
    // 메세지를 보낸 해당 사람에게 전송 (순서 2-2)
    socket.on('sendMsg', function(chatData) {
        //console.log('해당 사람한테만 보냄!');
        socket.emit('sendMsg', chatData); 
    });

    // 메세지를 보낸 해당 사람을 제외하고 모든사람들에게 전송 (순서2-3)
    socket.on('sendMsg', function(chatData) {
        //console.log('모든 사람한테 보냄!');
        //console.log(chatData);
        //DB에 채팅 데이터 삽입
        let date = new Date();
        let sql_str = 'INSERT INTO CHAT(chat_id, chat_name, chat_time, chat_msg) VALUES(?, ?, ?, ?)';
        db.query(sql_str, [chatData.userid, chatData.username, date, chatData.msg], (error) => {
            if(error) {
                console.log(error);
            } else {
               
            }
        });
        socket.broadcast.emit('sendMsg_broadcast', chatData); 
    });

    // 연결 끊겼을 때 (순서 3-2)
    socket.on('disconnect', function() { 
        //console.log(socket.name + '님이 나가셨습니다.');

        var object = {
            string : socket.name.name + '(' + socket.name.id  + ')' + '님이 나가셨습니다.',
            id :  socket.name.id ,
            name : socket.name.name
        };

        // 클라이언트 전역 배열에서 유저 제거
        for(var i = 0; i < __Clients.length; i++)
        {
            if( __Clients[i].id == object.id )
            {
                __Clients.splice(i, 1);
                break;
            }
        }

        // 나가는 사람을 제외한 나머지 유저에게 메시지 전송
        socket.broadcast.emit('disconnectNotice', object, __Clients);
    });   
 });
   
   
/*
    서버 ip 가져오는 함수
*/
function getServerIp() {
    var ifaces = os.networkInterfaces();
    var result = '';
    
    for (var key in ifaces) {
        ifaces[key].forEach(function(details, index) {
            if (details.family == 'IPv4' && details.internal === false) {
                result = details.address;
            }
        });
    }
    
    return result;
}

